double divide(double a, double b)
{
  return a/b;
}
