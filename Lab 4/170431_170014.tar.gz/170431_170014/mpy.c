double multiply(double a, double b)
{
  return a*b;
}
