--First a function calculate is defined which takes three numbers n a and b as arguments and calculates the nth fibonacci number
  The function executes n times and at each execution it takes the previous two fibonacci number yo calculate the nth fibonacci number
--Next a function fibonacci is defined which acts as a wrapper around calculate function
--Then an infinite list of all fibonacci numbers is produced, by iterating over each natural number

--First a function check_prime is defined which checks if a number is prime is not by going over all natural numbers less than
  input number and check if it divides the given number.
--Now an infinite list of prime numbers is created by iterating over all the natural numbers and adding it to the list if they
  are prime.
--Finally to get nth prime number nth element from the infinite list is extracted.
